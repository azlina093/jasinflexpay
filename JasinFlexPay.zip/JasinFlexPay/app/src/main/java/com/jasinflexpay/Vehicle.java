package com.jasinflexpay;

public class Vehicle {


    private String veh_num;
    private String manufacturer;
    private String model;
    private String phone_num;

    public Vehicle(String veh_num, String manufacturer, String model) {
        this.veh_num = veh_num;
        this.manufacturer = manufacturer;
        this.model = model;

    }

    public Vehicle() {

    }


    public void setVeh_num (String veh_num)
    {
        this.veh_num = veh_num;
    }

    public String getVeh_num()
    {
        return veh_num;
    }

    public void setManufacturer (String manufacturer)
    {
        this.manufacturer = manufacturer;
    }

    public String getManufacturer()
    {
        return manufacturer;
    }

    public void setModel (String model)
    {
        this.model = model;
    }

    public String getModel()
    {
        return model;
    }

    /**public void setPhone_num (String phone_num )
    {
        this.phone_num = phone_num;
    }

    public String getPhone_num()
    {
        return phone_num;
    }**/

}
