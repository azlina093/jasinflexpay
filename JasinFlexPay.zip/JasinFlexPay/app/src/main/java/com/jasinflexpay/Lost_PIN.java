package com.jasinflexpay;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Lost_PIN extends AppCompatActivity implements View.OnClickListener {

    Button hantar;
    EditText email;
    String emel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lost__pin);
        hantar = (Button) findViewById(R.id.butangsubmit);
        email = (EditText) findViewById(R.id.etMail);
        hantar.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_lost__pin, menu);
        return true;



    }

    boolean isEmailValid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email)
                .matches();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.butangsubmit:
                emel=email.getText().toString();
                if( isEmailValid(emel)) {
                    Toast.makeText(getApplicationContext(), "Valid Email Addresss", Toast.LENGTH_SHORT).show();
                    Intent i = null;
                    i = new Intent(this, Login.class);
                    Toast.makeText(this, "Your recover PIN has been sent..", Toast.LENGTH_SHORT).show();
                    startActivity(i);

                }else {
                    Toast.makeText(getApplicationContext(), "Invalid Email Addresss", Toast.LENGTH_SHORT).show();
                }



        }
    }
}
