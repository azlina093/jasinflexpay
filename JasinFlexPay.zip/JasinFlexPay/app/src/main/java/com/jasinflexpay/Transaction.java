package com.jasinflexpay;

public class Transaction {
    String veh_num,tarikh,timecheckin,timecheckout;
    int transId,points,hours,cost,OIC,OffID;


    public Transaction(String veh_num,String tarikh,String timecheckin,int transId,int points,int hours,int cost,int OIC,String timecheckout,int OffID) {
            this.transId=transId;
            this.points=points;
            this.veh_num = veh_num;
            this.tarikh= tarikh;
            this.timecheckin=timecheckin;
            this.hours=hours;
            this.cost= cost;
            this.OIC=OIC;
            this.timecheckout=timecheckout;
            this.OffID=OffID;

    }


    public Transaction() {

    }




    public void setTransId (int transId){this.transId = transId;}

    public Integer getTransId()
    {
        return transId;
    }

    public void setPoints (int points){this.points = points;}

    public Integer getPoints()
    {
        return points;
    }

    public void setVeh_num (String veh_num){  this.veh_num = veh_num;}

    public String getVeh_num()  {return veh_num;}

    public void setTarikh (String tarikh)
    {
        this.tarikh = tarikh;
    }

    public String getTarikh()
    {
        return tarikh;
    }



    public void setTimecheckin (String timecheckin){this.timecheckin = timecheckin;}

    public String getTimecheckin()
    {
        return timecheckin;
    }

    public void setHours (Integer hours)
    {
        this.hours = hours;
    }

    public Integer getHours()
    {
        return hours;
    }
    public void setCost (Integer cost)
    {
        this.cost = cost;
    }

    public Integer getCost()
    {
        return cost;
    }

    public void setOIC (Integer OIC)
    {
        this.OIC = OIC;
    }

    public Integer getOIC()
    {
        return OIC;
    }


    public void setTimecheckout (String timecheckout){this.timecheckout = timecheckout;}

    public String getTimecheckout()
    {
        return timecheckout;
    }



    public void setOffID (Integer OffID)
    {
        this.OffID = OffID;
    }
    public Integer getOffID()
    {
        return OffID;
    }




}