package com.jasinflexpay;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class Receipt extends AppCompatActivity{

    String veh,startt,datet,transId,vehStr, dateStr, timeStr,timecheckout;
    TextView phone_nume,veh_nume,starte,datee,stope,transe,jame;
    JSONParser jsonParser = new JSONParser();
    String url_create_mhs= "http://jasinflexpay.netii.net/crud_transaction/update_trans.php";

    public static final String TAG_SUCCESS = "success";
    public static final String TAG_TRANSID = "transId";
    public static final String TAG_TIMECHECKOUT = "timecheckout";


    private int mHour;
    private int mMinute;
    UserStore us;




    static final int TIME_DIALOG_ID1 = 1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);
        Bundle bundle = getIntent().getExtras();
        veh = bundle.getString("veh_num");
        startt = bundle.getString("timecheckin");
        datet = bundle.getString("tarikh");
        transId = bundle.getString("transId");

        jame = (TextView) findViewById(R.id.jam);
        phone_nume = (TextView) findViewById(R.id.tvnum);
        transe = (TextView) findViewById(R.id.tvtrans);
        veh_nume = (TextView) findViewById(R.id.tvveh);
        datee = (TextView) findViewById(R.id.tvdate);
        starte = (TextView) findViewById(R.id.tvparkd);
        stope = (TextView) findViewById(R.id.timeDisplay);

        veh_nume.setText(veh);
        starte.setText(startt);
        datee.setText(datet);
        transe.setText(transId);
        us = new UserStore(this);


        MyTimerTask myTask = new MyTimerTask();
        Timer myTimer = new Timer();
        myTimer.schedule(myTask, 1000,120000);
        //30 minutes = 1800000 miliseconds
    }
    public NotificationManager showNotification(){
        final Context context = this;
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        long when = System.currentTimeMillis();
        // intent triggered, you can add other intent for other actions
        Intent intent = new Intent(this,NotificationReceiver.class);
        PendingIntent pIntent = PendingIntent.getActivity(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT);
        Notification mNotification = new Notification.Builder(this)

                .setContentTitle("JASINFLEXPAY")
                .setContentText("Dont forget to tap STOP to check out.")
                .setSmallIcon(R.drawable.parkingicon)
                .setContentIntent(pIntent)
                .setSound(soundUri)
                .build();

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);


        // If you want to hide the notification after it was selected, do the code below
        mNotification.flags |= Notification.FLAG_AUTO_CANCEL;

        notificationManager.notify((int) when, mNotification);
        return notificationManager;

    }
    //120000- 2minute
    // 180000- 3 minutes
    //1800000-30 minutes
    public void open(View view){
        final Context context = this;
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure to stop your parking?");

        alertDialogBuilder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {


                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);


                // display the current date
                updateDisplaytime1();

                transId = transe.getText().toString();
                vehStr = veh_nume.getText().toString();
                dateStr = datee.getText().toString();
                timeStr = starte.getText().toString();
                timecheckout = stope.getText().toString();


                new UpdateMhsTask().execute();


            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();




    }


    @Override
    public void onBackPressed() {
        Toast.makeText(Receipt.this, "Tap STOP to check out", Toast.LENGTH_SHORT).show();
    }



    class MyTimerTask extends TimerTask {
        public void run() {
            showNotification();
        }
    }


    class UpdateMhsTask extends AsyncTask<String, Void, String>
    {
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(Receipt.this);
            pDialog.setMessage("Processing..");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        protected String doInBackground(String... args) {

            // Building Parameters
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair(TAG_TIMECHECKOUT, timecheckout));
            params.add(new BasicNameValuePair(TAG_TRANSID, transId));

            // getting JSON Object
            // Note that create Post url accepts POST method
            JSONObject json = jsonParser.makeHttpRequest(url_create_mhs, "POST", params);

            // check for success tag
            try {
                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {
                    // closing this screen
                    finish();
                } else {
                    return "Database Failed";
                }
            } catch (JSONException e) {
                e.printStackTrace();
                return "Connection Failed_or_exception";
            }

            return "success";

        }


        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            if (result.equalsIgnoreCase("failed")) {
                pDialog.dismiss();
                Toast.makeText(Receipt.this, "Connection Failed!", Toast.LENGTH_SHORT).show();
            } else if (result.equalsIgnoreCase("failed")) {
                pDialog.dismiss();
                Toast.makeText(Receipt.this, "Connection Failed!", Toast.LENGTH_SHORT).show();

            } else if (result.equalsIgnoreCase("success")) {
                pDialog.dismiss();
                Intent i = null;
                i = new Intent(Receipt.this, Receipt_2.class);
                i.putExtra("veh_num", vehStr);
                i.putExtra("tarikh", dateStr);
                i.putExtra("timecheckin", timeStr);
                i.putExtra("timecheckout", timecheckout);
                i.putExtra("transId", transId);

                startActivity(i);
            }
        }
    }

    @Override
    protected Dialog onCreateDialog(int id){

        Dialog myDialog = null;

        switch(id){

            case TIME_DIALOG_ID1:
                //set time picker as current time
                myDialog = new TimePickerDialog(this,
                        mTimeSetListener1, mHour, mMinute, false);
                break;}

        return myDialog;

    }


    private void updateDisplaytime1() {
        stope.setText(
                new StringBuilder()
                        .append(pad(mHour)).append(":")
                        .append(pad(mMinute)));
    }

    // the callback received when the user "sets" the time in the dialog
    private TimePickerDialog.OnTimeSetListener mTimeSetListener1 =
            new TimePickerDialog.OnTimeSetListener() {
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    mHour = hourOfDay;
                    mMinute = minute;
                    updateDisplaytime1();



                }
            };

    private static String pad(int c) {
        if (c >= 10)
            return String.valueOf(c);
        else
            return "0" + String.valueOf(c);
    }


    @Override
    protected void onStart() {
        super.onStart();
        if (authenticate()== true) {
            displayUserDetails();
        }
    }
    private boolean authenticate(){
        if (us.getLoggedInUser() == null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            return false;
        }
        return true;
    }

    private void displayUserDetails(){
        User user = us.getLoggedInUser();





    }


}
