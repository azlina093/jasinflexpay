package com.jasinflexpay;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class Edit_Vehicle extends AppCompatActivity {
    ListView list;

    JSONParser jParser = new JSONParser();
    ArrayList<Vehicle> daftar_mhs = new ArrayList<Vehicle>();
    JSONArray daftarMhs = null;
    String url_read_mhs = "http://jasinflexpay.netii.net/crud_vehicle/read_vehicle.php?phone_num=";
    UserStore us;





    public static final String TAG_SUCCESS = "success";
    public static final String TAG_VEHICLE = "vehicle";
    public static final String TAG_VEH_NUM= "veh_num";
    public static final String TAG_MANUFACTURER = "manufacturer";
    public static final String TAG_MODEL = "model";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit__vehicle);
        us = new UserStore(this);


        list = (ListView) findViewById(R.id.listview_veh);



        ReadMhsTask m = (ReadMhsTask) new ReadMhsTask().execute();

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int urutan, long id) {

                String veh_num = ((TextView) view.findViewById(R.id.veh_num_veh)).getText().toString();
                String manufacturer = ((TextView) view.findViewById(R.id.manufacturer_veh)).getText().toString();
                String model = ((TextView) view.findViewById(R.id.model_veh)).getText().toString();

                Intent i = null;
                i = new Intent(Edit_Vehicle.this, UpdateDeleteActivity.class);
                Bundle b = new Bundle();
                b.putString("veh_num", veh_num);
                b.putString("manufacturer", manufacturer);
                b.putString("model", model);
                i.putExtras(b);
                startActivity(i);



            }
        });


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit__vehicle, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();


        if (id == R.id.action_add) {
            Intent i = new Intent(Edit_Vehicle.this, AddVehicle.class);
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    class ReadMhsTask extends AsyncTask<String, Void, String>
    {
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(Edit_Vehicle.this);
            pDialog.setMessage("Processing..");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        @Override
        protected String doInBackground(String... sText) {
            String returnResult = getVehList();
            return returnResult;

        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pDialog.dismiss();
            if(result.equalsIgnoreCase("Exception Caught"))
            {
                Toast.makeText(Edit_Vehicle.this, "Unable to connect to server,please check your internet connection!", Toast.LENGTH_LONG).show();
            }

            if(result.equalsIgnoreCase("no results"))
            {
                Toast.makeText(Edit_Vehicle.this, "Data empty", Toast.LENGTH_LONG).show();
            }
            else
            {
                list.setAdapter(new VehicleAdapter(Edit_Vehicle.this,daftar_mhs));
            }
        }



        public String getVehList()
        {
            Vehicle tempMhs = new Vehicle();

            List<NameValuePair> parameter = new ArrayList<NameValuePair>();
            try {
                User user = us.getLoggedInUser();
                JSONObject json = jParser.makeHttpRequest(url_read_mhs+user.phone_num,"POST", parameter);

                int success = json.getInt(TAG_SUCCESS);
                if (success == 1) {
                    daftarMhs = json.getJSONArray(TAG_VEHICLE);
                    for (int i = 0; i < daftarMhs.length() ; i++){
                        JSONObject c = daftarMhs.getJSONObject(i);
                        tempMhs = new Vehicle();
                        tempMhs.setVeh_num(c.getString(TAG_VEH_NUM));
                        tempMhs.setManufacturer(c.getString(TAG_MANUFACTURER));
                        tempMhs.setModel(c.getString(TAG_MODEL));
                        daftar_mhs.add(tempMhs);
                    }
                    return "OK";
                }
                else {

                    return "no results";
                }

            } catch (Exception e) {
                e.printStackTrace();
                return "Exception Caught";
            }
        }

    }

}
