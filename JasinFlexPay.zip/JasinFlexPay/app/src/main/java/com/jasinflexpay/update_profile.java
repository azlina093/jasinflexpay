package com.jasinflexpay;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class update_profile extends AppCompatActivity {

    JSONParser jParser = new JSONParser();
    String url_update_mhs= "http://jasinflexpay.netii.net/crud_profile/update_profile.php";
    public static final String TAG_SUCCESS = "success";
    public static final String TAG_NAMA_MHS = "name";
    public static final String TAG_IC_MHS = "ic";
    public static final String TAG_PHONE_MHS = "phone_num";

    EditText EditTxtnama, EditTxtic, TxtViewPhone;
    Button UpdateBtn;
    String namaStr, icStr, phoneStr;
    UserStore us;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        EditTxtnama = (EditText) findViewById(R.id.etnama);
        EditTxtic = (EditText) findViewById(R.id.etic);
        TxtViewPhone = (EditText) findViewById(R.id.etnum);
        UpdateBtn = (Button) findViewById(R.id.btUpdate);
        us = new UserStore(this);

        UpdateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                namaStr = EditTxtnama.getText().toString();
                icStr = EditTxtic.getText().toString();
                phoneStr = TxtViewPhone.getText().toString();

                if (EditTxtnama.getText().length() == 0)
                    EditTxtnama.setError("please enter Name");

                if (EditTxtic.getText().length() == 0)
                    EditTxtic.setError("please enter Identification Number");

                if ((EditTxtnama.getText().length() > 0)
                        && (EditTxtic.getText().length() > 0)) {new UpdateMhsTask().execute();}
            }
        });



    }



    @Override
    protected void onStart() {
        super.onStart();
        if (authenticate() == true) {
            displayUserDetails();
        }
    }

    private boolean authenticate() {
        if (us.getLoggedInUser() == null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            return false;
        }
        return true;
    }

    private void displayUserDetails() {
        User user = us.getLoggedInUser();

        EditTxtnama.setText(user.name);
        EditTxtic.setText(user.ic);
        TxtViewPhone.setText(user.phone_num);



    }

    class UpdateMhsTask extends AsyncTask<String, Void, String>
    {
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(update_profile.this);
            pDialog.setMessage("Processing..");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        protected String doInBackground(String... args) {

            // Building Parameters
            List<NameValuePair> params = new ArrayList<>();

            params.add(new BasicNameValuePair(TAG_NAMA_MHS,namaStr));
            params.add(new BasicNameValuePair(TAG_IC_MHS,icStr));
            params.add(new BasicNameValuePair(TAG_PHONE_MHS,phoneStr));

            // getting JSON Object
            // Note that create Post url accepts POST method
            JSONObject json = jParser.makeHttpRequest(url_update_mhs, "POST", params);

            // check for success tag
            try {
                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {
                    // closing this screen
                    finish();
                } else {
                    return "Database Failed";
                }
            } catch (JSONException e) {
                e.printStackTrace();
                return "Connection Failed_or_exception";
            }

            return "success";

        }


        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            if (result.equalsIgnoreCase("failed")){
                pDialog.dismiss();
                Toast.makeText(update_profile.this, "Connection Failed!", Toast.LENGTH_SHORT).show();
            }
            else if (result.equalsIgnoreCase("failed")){
                pDialog.dismiss();
                Toast.makeText(update_profile.this, "Connection Failed!", Toast.LENGTH_SHORT).show();

            }
            else if (result.equalsIgnoreCase("success")){
                pDialog.dismiss();
                Toast.makeText(update_profile.this, "Profile has been updated, redirecting to login page...", Toast.LENGTH_SHORT).show();
                Intent i = null;
                i = new Intent(update_profile.this, Login.class);
                startActivity(i);
                finish();




                }

            }

        }
    }
