package com.jasinflexpay;


public class User {

    String name,phone_num,ic;
    int pin,pin2,points;

    public User(String name, String ic, String phone_num, int pin, int pin2,int points)
    {
        this.name=name;
        this.ic=ic;
        this.phone_num=phone_num;
        this.pin=pin;
        this.pin2=pin2;
        this.points=points;

    }

    public User(String phone_num, int pin)
    {
        this("","",phone_num, pin,-1,-1);

    }


}
