package com.jasinflexpay;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    //private NavigationDrawerFragment mNavigationDrawerFragment;
    //private CharSequence mTitle;
    ImageView btLogout, btTrans, btInfo, btHistory, btView;
    EditText etName;
    UserStore us;




    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      /**  mNavigationDrawerFragment = (NavigationDrawerFragment)
                getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);
        mTitle = getTitle();

        // Set up the drawer.
        mNavigationDrawerFragment.setUp(
                R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));**/

        etName = (EditText) findViewById(R.id.et);
        btLogout = (ImageView) findViewById(R.id.btLogout);
        btTrans = (ImageView) findViewById(R.id.btTrans);
        btHistory = (ImageView) findViewById(R.id.btHistory);
        btInfo= (ImageView) findViewById(R.id.btInfo);
        btView = (ImageView) findViewById(R.id.btView);

        btLogout.setOnClickListener(this);
        btTrans.setOnClickListener(this);
        btHistory.setOnClickListener(this);
        btInfo.setOnClickListener(this);
        btView.setOnClickListener(this);

        us = new UserStore(this);
    }





    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btLogout:
                final Context context = this;

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setMessage("Are you sure to want to log out?");


                alertDialogBuilder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        us.clearUserData();
                        us.setUserLoggedIn(false);

                        Intent loginIntent = new Intent(MainActivity.this, Login.class);
                        startActivity(loginIntent);
                    }
                });


                alertDialogBuilder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent intent = new Intent(context, MainActivity.class);
                        startActivity(intent);
                    }
                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();


                break;

            case R.id.btTrans:
                Intent transIntent = new Intent(this, New_Transaction.class);
                startActivity(transIntent);
                break;

            case R.id.btHistory:
                Intent historyIntent = new Intent(this, History.class);
                startActivity(historyIntent);
                break;

            case R.id.btInfo:
                Intent infoIntent = new Intent(this, ParkingInfo.class);
                startActivity(infoIntent);
            break;
            case R.id.btView:
                Intent viewIntent = new Intent(this, view_profile.class);
                startActivity(viewIntent);

                break;


        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (authenticate()== true) {
            displayUserDetails();
        }
    }
    private boolean authenticate(){
        if (us.getLoggedInUser() == null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            return false;
        }
        return true;
    }

    private void displayUserDetails(){
        User user = us.getLoggedInUser();
            etName.setText(user.name);
    }

    @Override
    public void onBackPressed() {
    }

/**    @Override
    public void onNavigationDrawerItemSelected(int position) {
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, PlaceholderFragment.newInstance(position + 1))
                .commit();
    }

    public void onSectionAttached(int number) {
        switch (number) {
            case 1:
                mTitle = getString(R.string.title_section1);
                break;
            case 2:
                mTitle = getString(R.string.title_section2);
                break;
            case 3:
                mTitle = getString(R.string.title_section3);
                break;
        }
    }

    public void restoreActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setTitle(mTitle);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (!mNavigationDrawerFragment.isDrawerOpen()) {
            // Only show items in the action bar relevant to this screen
            // if the drawer is not showing. Otherwise, let the drawer
            // decide what to show in the action bar.
            getMenuInflater().inflate(R.menu.main, menu);
            restoreActionBar();
            return true;
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public static class PlaceholderFragment extends Fragment {

        private static final String ARG_SECTION_NUMBER = "section_number";


        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            return rootView;
        }

        @Override
        public void onAttach(Activity activity) {
            super.onAttach(activity);
            ((MainActivity) activity).onSectionAttached(
                    getArguments().getInt(ARG_SECTION_NUMBER));


        }

    }**/

}
