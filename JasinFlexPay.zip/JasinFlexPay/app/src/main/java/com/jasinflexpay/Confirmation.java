package com.jasinflexpay;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Confirmation extends AppCompatActivity implements View.OnClickListener {

    Button btSubmit, btCancel,btNoti;
    TextView phone_nume,veh_nume,starte,datee,ponti,randomResult;
    UserStore us;
    String veh,startt,datet,point,phoneStr, pointsStr,vehStr, dateStr, timeStr,resut;
    Random myRandom;


    JSONParser jsonParser = new JSONParser();
    String url_create_mhs= "http://jasinflexpay.netii.net/crud_transaction/create_trans.php";

    public static final String TAG_SUCCESS = "success";
    public static final String TAG_PHONE = "phone_num";
    public static final String TAG_POINTS = "points";
    public static final String TAG_VEH_NUM = "veh_num";
    public static final String TAG_DATE = "tarikh";
    public static final String TAG_TIME = "timecheckin";
    public static final String TAG_RAND = "transId";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        //ni utk call drpd previous
        Bundle bundle=getIntent().getExtras();
        veh=bundle.getString("veh_num");
        startt=bundle.getString("timecheckin");
        datet=bundle.getString("tarikh");
        point=bundle.getString("points");

        //text view
        phone_nume = (TextView) findViewById(R.id.tvmobnum);
        veh_nume = (TextView) findViewById(R.id.tvvehnum);
        datee = (TextView) findViewById(R.id.tvdate);
        starte= (TextView) findViewById(R.id.tvparkexp);
        randomResult= (TextView) findViewById(R.id.randomm);
        ponti= (TextView) findViewById(R.id.tvpoint);
        btSubmit = (Button) findViewById(R.id.btSubmit);
        btCancel = (Button) findViewById(R.id.btCancel);



        resut = "";
        myRandom = new Random();
        resut = String.valueOf(myRandom.nextInt());
        randomResult.setText(resut);


        //set text view dgn value yg kte panggil
        veh_nume.setText(veh);
        starte.setText(startt);
        datee.setText(datet);
        ponti.setText(point);



        btSubmit.setOnClickListener(this);
        btCancel.setOnClickListener(this);
        us = new UserStore(this);


    }


    @Override
    protected void onStart() {
        super.onStart();
        if (authenticate()== true) {
            displayUserDetails();
        }
    }
    private boolean authenticate(){
        if (us.getLoggedInUser() == null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            return false;
        }
        return true;
    }

    private void displayUserDetails(){
        User user = us.getLoggedInUser();
         phone_nume.setText(user.phone_num);




    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {



            case R.id.btSubmit:

                    resut = randomResult.getText().toString();
                    phoneStr = phone_nume.getText().toString();
                    pointsStr = ponti.getText().toString();
                    vehStr = veh_nume.getText().toString();
                    dateStr = datee.getText().toString();
                    timeStr = starte.getText().toString();
                    new CreateMhsTask().execute();

                break;

            case R.id.btCancel:
                Intent homePageIntent = new Intent(this, MainActivity.class);
                startActivity(homePageIntent);

        }
    }

    class CreateMhsTask extends AsyncTask<String, String, String> {
        ProgressDialog dialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(Confirmation.this);
            dialog.setMessage("Processing...");
            dialog.setIndeterminate(false);
            dialog.setCancelable(false);
            dialog.show();
        }

        protected String doInBackground(String... args) {

            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();

            params.add(new BasicNameValuePair(TAG_RAND, resut));
            params.add(new BasicNameValuePair(TAG_PHONE, phoneStr));
            params.add(new BasicNameValuePair(TAG_POINTS, pointsStr));
            params.add(new BasicNameValuePair(TAG_VEH_NUM, vehStr));
            params.add(new BasicNameValuePair(TAG_DATE, dateStr));
            params.add(new BasicNameValuePair(TAG_TIME, timeStr));


            // getting JSON Object
            // Note that create Post url accepts POST method

            JSONObject json = jsonParser.makeHttpRequest(url_create_mhs, "POST", params);

            // check for success tag
            try {
                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {
                    // closing this screen
                    finish();
                } else {
                    return "Database Failed";
                }
            } catch (JSONException e) {
                e.printStackTrace();
                return "Connection Failed_or_exception";
            }

            return "success";

        }


        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            if (result.equalsIgnoreCase("failed")){
                dialog.dismiss();
                Toast.makeText(Confirmation.this, "Connection Failed!", Toast.LENGTH_SHORT).show();
            }
            else if (result.equalsIgnoreCase("failed")){
                dialog.dismiss();
                Toast.makeText(Confirmation.this, "Connection Failed!", Toast.LENGTH_SHORT).show();

            }
            else if (result.equalsIgnoreCase("success")){
                dialog.dismiss();
                Intent i = null;
                i = new Intent(Confirmation.this, Receipt.class);
                i.putExtra("veh_num", vehStr);
                i.putExtra("tarikh", dateStr);
                i.putExtra("timecheckin", timeStr);
                i.putExtra("transId", resut);
                startActivity(i);



            }
        }
    }
    @Override
    public void onBackPressed() {
    }
}

