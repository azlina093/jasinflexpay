package com.jasinflexpay;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class New_Transaction extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {





    Button btVeh, btSubmit;
    Spinner pusing1;
    TextView mDateDisplay, mTimeDisplay;
    EditText points,phone_nume;
    private ArrayList<Vehicle> vehList;
    ProgressDialog pDialog;
    UserStore us;
    String phoneStr,pointsStr,vehStr, dateStr, timeStr;


    //time
    private int mHour;
    private int mMinute;

    static final int TIME_DIALOG_ID1 = 1;



    //calender
    private int mYear;
    private int mMonth;
    private int mDay;

    static final int DATE_DIALOG_ID = 0;
    private String URL_VEHICLE = "http://jasinflexpay.netii.net/crud_vehicle/read_vehicle.php?phone_num=";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_transaction);

        pusing1 = (Spinner) findViewById(R.id.spinner1);

        points = (EditText) findViewById(R.id.etpoints);
        phone_nume= (EditText) findViewById(R.id.etphone);
        btVeh = (Button) findViewById(R.id.btVeh);
        btSubmit = (Button) findViewById(R.id.btSubmit);
        mDateDisplay = (TextView) findViewById(R.id.dateDisplay);
        mTimeDisplay = (TextView) findViewById(R.id.timeDisplay);


        // get the current date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        // display the current date (this method is below)
        updateDisplay();

        // final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        // display the current date
        updateDisplaytime1();



        btVeh.setOnClickListener(this);
        btSubmit.setOnClickListener(this);

        vehList = new ArrayList<Vehicle>();
        pusing1.setOnItemSelectedListener(this);




        us = new UserStore(this);



        new getVehicle().execute();




    }
    @Override
    protected void onStart() {
        super.onStart();
        if (authenticate()== true) {
            displayUserDetails();
        }
    }
    private boolean authenticate(){
        if (us.getLoggedInUser() == null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            return false;
        }
        return true;
    }

    private void displayUserDetails() {
        User user = us.getLoggedInUser();
        phone_nume.setText(user.phone_num);
        points.setText(String.valueOf(user.points));


    }


        @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()) {
            case R.id.spinner1:
                Toast.makeText(
                        getApplicationContext(),
                         parent.getItemAtPosition(position).toString() + " Selected",
                        Toast.LENGTH_SHORT).show();


                break;

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }




    private class getVehicle extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(New_Transaction.this);
            pDialog.setMessage("Fetching vehicles..");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            serviceHandler jsonParser = new serviceHandler();
            User user = us.getLoggedInUser();
            String json = jsonParser.makeServiceCall(URL_VEHICLE+user.phone_num, serviceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray vehicle = jsonObj
                                .getJSONArray("vehicle");

                        for (int i = 0; i <vehicle.length(); i++) {
                            JSONObject catObj = (JSONObject) vehicle.get(i);
                            Vehicle cat = new Vehicle(catObj.getString("veh_num"),catObj.getString("manufacturer"),catObj.getString("model"));
                            vehList.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "Didn't receive any data from server!");
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            if (pDialog.isShowing())
                pDialog.dismiss();
                populateSpinner();
        }

    }

    /**
     * Adding spinner data
     * */
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();



        for (int i = 0; i < vehList.size(); i++) {
            lables.add(vehList.get(i).getVeh_num());
        }

        // Creating adapter for spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);

        // Drop down layout style - list view with radio button
        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        pusing1.setAdapter(spinnerAdapter);
    }




    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btVeh:

                Intent VehIntent = new Intent(this, Edit_Vehicle.class);
                startActivity(VehIntent);
                break;

            case R.id.btSubmit:
                User user = us.getLoggedInUser();
                if (mHour==18||mHour==19||mHour==20||mHour==21||mHour==22||mHour==23||mHour==00||mHour==01||mHour==02||mHour==03||mHour==04||
                        mHour==05||mHour==06||mHour==07){
                    Toast.makeText(New_Transaction.this, "Now are not in enforcement time", Toast.LENGTH_LONG).show();
                    btSubmit = (Button) findViewById(R.id.btSubmit);
                    btSubmit.setEnabled(false);

                }else{

                if (user.points<20) {
                    Toast.makeText(New_Transaction.this, "Please reload your Flexpoints at nearest store", Toast.LENGTH_LONG).show();
                    btSubmit = (Button) findViewById(R.id.btSubmit);
                    btSubmit.setEnabled(false);
                }else {


                    btSubmit.setEnabled(true);
                    phoneStr = phone_nume.getText().toString();
                    pointsStr = points.getText().toString();
                    vehStr = ((Spinner) findViewById(R.id.spinner1)).getSelectedItem().toString();
                    dateStr = mDateDisplay.getText().toString();
                    timeStr = mTimeDisplay.getText().toString();

                    Intent i = null;
                    i = new Intent(New_Transaction.this, Confirmation.class);
                    i.putExtra("phone_nume", phoneStr);
                    i.putExtra("points", pointsStr);
                    i.putExtra("veh_num", vehStr);
                    i.putExtra("tarikh", dateStr);
                    i.putExtra("timecheckin", timeStr);
                    startActivity(i);

                }
                }
        }
    }



   @Override
   protected Dialog onCreateDialog(int id){

    Dialog myDialog = null;

    switch(id){


        case DATE_DIALOG_ID:
            // set date picker as current date
            myDialog = new DatePickerDialog(this,
                    mDateSetListener,
                    mYear, mMonth, mDay);
            break;

        case TIME_DIALOG_ID1:
            //set time picker as current time
            myDialog = new TimePickerDialog(this,
                    mTimeSetListener1, mHour, mMinute, false);
            break;}

    return myDialog;

}



        private void updateDisplay() {
            mDateDisplay.setText(
                    new StringBuilder()
                            // Month is 0 based so add 1
                            .append(mYear).append("-")
                            .append(mMonth +1 ).append("-")
                            .append(mDay).append(" "));
        }


        private DatePickerDialog.OnDateSetListener mDateSetListener =
                new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        mYear = year;
                        mMonth = monthOfYear;
                        mDay = dayOfMonth;
                        updateDisplay();
                    }
                };



    // clock2



    private void updateDisplaytime1() {
        mTimeDisplay.setText(
                new StringBuilder()
                        .append(pad(mHour)).append(":")
                        .append(pad(mMinute)));
    }

    // the callback received when the user "sets" the time in the dialog
    private TimePickerDialog.OnTimeSetListener mTimeSetListener1 =
            new TimePickerDialog.OnTimeSetListener() {
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    mHour = hourOfDay;
                    mMinute = minute;
                    updateDisplaytime1();
                }
            };

    private static String pad(int c) {
        if (c >= 10)
            return String.valueOf(c);
        else
            return "0" + String.valueOf(c);
    }



}






