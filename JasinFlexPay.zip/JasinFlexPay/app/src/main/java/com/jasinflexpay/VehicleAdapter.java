package com.jasinflexpay;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class VehicleAdapter extends BaseAdapter {
    private Activity activity;
    //private ArrayList<HashMap<String, String>> data;
    private ArrayList<Vehicle> data_mhs = new ArrayList<Vehicle>();

    private static LayoutInflater inflater = null;
    public Vehicle getVehList;

    public VehicleAdapter(Activity a, ArrayList<Vehicle> d) {
        activity = a;
        data_mhs = d;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public VehicleAdapter(Confirmation confirmation) {

    }

    public int getCount() {
        return data_mhs.size();
    }

    public Object getItem(int position) {
        return data_mhs.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (convertView == null)
            vi = inflater.inflate(R.layout.activity_list_item_veh, null);
        TextView veh_num = (TextView) vi.findViewById(R.id.veh_num_veh);
        TextView manufacturer = (TextView) vi.findViewById(R.id.manufacturer_veh);
        TextView model = (TextView) vi.findViewById(R.id.model_veh);
       // TextView phone_num = (TextView) vi.findViewById(R.id.phone_num_veh);


        Vehicle daftar_mhs = data_mhs.get(position);
        veh_num.setText(daftar_mhs.getVeh_num());
        manufacturer.setText(daftar_mhs.getManufacturer());
        model.setText(daftar_mhs.getModel());
       // phone_num.setText(daftar_mhs.getPhone_num());

        return vi;
    }
}