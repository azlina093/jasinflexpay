package com.jasinflexpay;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Receipt_2 extends AppCompatActivity implements View.OnClickListener {


        String veh, startt, datet, stopp,point,phone_num;
        TextView veh_nume, starte, datee, pointe, stope, jame;
        UserStore us;
        double total,charges,foo;
        int pointAfter;
    JSONParser jsonParser = new JSONParser();
    String url_create_mhs= "http://jasinflexpay.netii.net/crud_transaction/update_trans2.php";
    public static final String TAG_SUCCESS = "success";
    public static final String TAG_PHONENUM = "phone_num";
    public static final String TAG_POINTS = "points";





        @Override
        protected void onCreate (Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_receipt2);
            Bundle bundle = getIntent().getExtras();
            veh = bundle.getString("veh_num");
            startt = bundle.getString("timecheckin");
            datet = bundle.getString("tarikh");
            stopp = bundle.getString("timecheckout");

            us = new UserStore(this);


            SimpleDateFormat format = new SimpleDateFormat("HH:mm");

            Date d1 = null;
            Date d2 = null;

            try {
                d1 = format.parse(startt);
                d2 = format.parse(stopp);

                //in milliseconds
                long diff = d2.getTime() - d1.getTime();

                long diffMinutes = diff / (60 * 1000) % 60;
                long diffHours = diff / (60 * 60 * 1000) % 24;

                System.out.println(diffHours + " hours, ");
                System.out.println(diffMinutes + " minutes, ");



                    User user =us.getLoggedInUser();
                    phone_num=user.phone_num;
                    foo = user.points;

                    double diffMinfloor = Math.floor(diff/(60*1000));
                charges = Math.floor(diffMinfloor/2)*2;
                    //-30minit/10 points
                   total = foo- charges;


                //charges = Math.floor(diffMinfloor/2)*2; -2minit/2 points
                //charges = Math.floor(diffMinfloor/30)*10; -30minit/10 points
            } catch (Exception e) {
                e.printStackTrace();
            }

            veh_nume = (TextView) findViewById(R.id.tvveh);
            datee = (TextView) findViewById(R.id.tvdate);
            starte = (TextView) findViewById(R.id.tvparkd);
            stope = (TextView) findViewById(R.id.tvparkdend);
            pointe = (TextView) findViewById(R.id.tvpointss);
            jame = (TextView) findViewById(R.id.jam);

            veh_nume.setText(veh);
            starte.setText(startt);
            stope.setText(stopp);
            datee.setText(datet);
            Double d = total;
            pointAfter = d.intValue();
            pointe.setText(Integer.toString(pointAfter));

        }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btHome:

                point = pointe.getText().toString();
                new UpdateMhsTask().execute();

        }
    }


    class UpdateMhsTask extends AsyncTask<String, Void, String>
    {
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(Receipt_2.this);
            pDialog.setMessage("Processing..");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        protected String doInBackground(String... args) {

            // Building Parameters
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair(TAG_POINTS, point));
            params.add(new BasicNameValuePair(TAG_PHONENUM, phone_num));

            // getting JSON Object
            // Note that create Post url accepts POST method
            JSONObject json = jsonParser.makeHttpRequest(url_create_mhs, "POST", params);

            // check for success tag
            try {
                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {
                    // closing this screen
                    finish();
                } else {
                    return "Database Failed";
                }
            } catch (JSONException e) {
                e.printStackTrace();
                return "Connection Failed_or_exception";
            }

            return "success";

        }


        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            if (result.equalsIgnoreCase("failed")) {
                pDialog.dismiss();
                Toast.makeText(Receipt_2.this, "Connection Failed!", Toast.LENGTH_SHORT).show();
            } else if (result.equalsIgnoreCase("failed")) {
                pDialog.dismiss();
                Toast.makeText(Receipt_2.this, "Connection Failed!", Toast.LENGTH_SHORT).show();

            } else if (result.equalsIgnoreCase("success")) {
                pDialog.dismiss();
                Intent i = null;
                i = new Intent(Receipt_2.this, Login.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Toast.makeText(Receipt_2.this, "Thanks for using our service. Redirect to Login page..", Toast.LENGTH_SHORT).show();
                startActivity(i);
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        }
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(Receipt_2.this, "Tap Exit", Toast.LENGTH_SHORT).show();

    }



}
