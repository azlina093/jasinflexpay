package com.jasinflexpay;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class view_profile extends AppCompatActivity {


    UserStore us;
    EditText etName,etIc,etNum,etpoints;
    Button btnUpdate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        etName = (EditText) findViewById(R.id.etnama);
        etIc = (EditText) findViewById(R.id.etic);
        etNum = (EditText) findViewById(R.id.ettelepon);
        etpoints = (EditText) findViewById(R.id.etpoints);
     
        us = new UserStore(this);
        addListenerOnButton();

    }

    public void addListenerOnButton() {

        final Context context = this;

        btnUpdate = (Button) findViewById(R.id.btUpdate);

        btnUpdate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(context, update_profile.class);
                startActivity(intent);

            }

        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (authenticate()== true) {
            displayUserDetails();
        }
    }
    private boolean authenticate(){
        if (us.getLoggedInUser() == null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            return false;
        }
        return true;
    }

    private void displayUserDetails(){
        User user = us.getLoggedInUser();
        etName.setText(user.name);
        etIc.setText(user.ic);
        etNum.setText(user.phone_num);
        etpoints.setText(String.valueOf(user.points));

    }






}
