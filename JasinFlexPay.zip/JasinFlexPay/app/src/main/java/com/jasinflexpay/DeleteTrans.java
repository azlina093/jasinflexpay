package com.jasinflexpay;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DeleteTrans extends AppCompatActivity {


    JSONParser jParser = new JSONParser();
    String url_delete_mhs= "http://jasinflexpay.netii.net/crud_transaction/delete_trans.php";

    public static final String TAG_SUCCESS = "success";
    public static final String TAG_TRANS_ID = "transId";

    Button DeleteBtn;
    String  transIdStr;
    TextView transe,pointe,veh_nume,starte,datee,stope;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_trans);



        DeleteBtn = (Button) findViewById(R.id.buttonDelete);

        Bundle b = getIntent().getExtras();
        String transId = b.getString("transId");
        String points = b.getString("points");
        String veh_num= b.getString("veh_num");
        String tarikh= b.getString("tarikh");
        String timecheckin= b.getString("timecheckin");
        String timecheckout= b.getString("timecheckout");

        transe= (TextView) findViewById(R.id.tvtrans);
        pointe= (TextView) findViewById(R.id.tvpointsss);
        veh_nume = (TextView) findViewById(R.id.tvkereta);
        datee = (TextView) findViewById(R.id.tvtarikh);
        starte= (TextView) findViewById(R.id.tvstart);
        stope= (TextView) findViewById(R.id.tvend);


        transe.setText(transId);
        pointe.setText(points);
        veh_nume.setText(veh_num);
        datee.setText(tarikh);
        starte.setText(timecheckin);
        stope.setText(timecheckout);



        DeleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                transIdStr = transe.getText().toString();
                new DeleteMhsTask().execute();
            }
        });

    }



    class DeleteMhsTask extends AsyncTask<String, Void, String>
    {
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(DeleteTrans.this);
            pDialog.setMessage("Processing..");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        @Override
        protected String doInBackground(String... sText) {

            List<NameValuePair> parameter = new ArrayList<NameValuePair>();
            parameter.add(new BasicNameValuePair(TAG_TRANS_ID, transIdStr));

            try {
                JSONObject json = jParser.makeHttpRequest(url_delete_mhs,"POST", parameter);

                int success = json.getInt(TAG_SUCCESS);
                if (success == 1) {

                    return "OK";
                }
                else {

                    return "FAIL";

                }

            } catch (Exception e) {
                e.printStackTrace();
                return "Exception Caught";
            }

        }

        @Override
        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            pDialog.dismiss();

            if(result.equalsIgnoreCase("Exception Caught"))
            {

                Toast.makeText(DeleteTrans.this, "Unable to connect to server,please check your internet connection!", Toast.LENGTH_LONG).show();
            }

            if(result.equalsIgnoreCase("FAIL"))
            {
                Toast.makeText(DeleteTrans.this, "Fail.. Try Again", Toast.LENGTH_LONG).show();
            }

            else {
                Intent i = null;
                i = new Intent(DeleteTrans.this, History.class);
                startActivity(i);
            }

        }
    }

}
