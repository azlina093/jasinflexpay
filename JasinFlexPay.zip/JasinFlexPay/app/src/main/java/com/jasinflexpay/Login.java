package com.jasinflexpay;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity implements View.OnClickListener {

        Button btLogin;
        EditText etNumber;
    EditText etPassword;
        TextView tv ;
        UserStore us;
        String phone_num;
        int pin;



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login);


            btLogin = (Button) findViewById(R.id.btLogin);
            etNumber = (EditText) findViewById(R.id.etNumber);
            etPassword = (EditText) findViewById(R.id.etPassword);
            tv = (TextView)findViewById(R.id.btRegister);


            btLogin.setOnClickListener(this);
            tv.setOnClickListener(this);
            us = new UserStore(this);
        }

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btLogin:

                    phone_num = etNumber.getText().toString();
                    //pin = Integer.parseInt(etPassword.getText().toString());
                    if (etPassword.getText().toString().matches("")) {
                        etPassword.equals("0");
                    }


                    if(etNumber.getText().toString().length() == 0 )
                        etNumber.setError( "Phone Number is required!" );

                    if(etNumber.getText().toString().length() < 10 )
                        etNumber.setError( "Please enter valid Phone Number!" );


                    if(etPassword.getText().length() == 0 ){
                        etPassword.setError( "PIN is required!" );}
                    else
                    {pin = Integer.parseInt(etPassword.getText().toString());}


                        if ((etNumber.getText().toString().length() > 0)
                                && (etPassword.getText().length() > 0)) {

                            User user = new User(phone_num, pin);

                            authenticate(user);
                        }
                    else
                        {
                            Toast.makeText(Login.this, "Login form is empty", Toast.LENGTH_SHORT).show();

                        }



                    break;
                case R.id.btRegister:
                    Intent registerIntent = new Intent(this, Registration.class);
                    startActivity(registerIntent);
                    break;

            }

        }


    private void authenticate(User user) {
        ServerRequest serverRequest = new ServerRequest(this);
        serverRequest.fetchUserDataAsyncTask(user, new GetUserCallback() {
            @Override
            public void done(User returnedUser) {
                if (returnedUser == null) {
                    showErrorMessage();
                } else {
                    logUserIn(returnedUser);
                }
            }
        });
    }

    private void showErrorMessage() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(Login.this);
        dialogBuilder.setMessage("Mobile Number and PIN does not match.");
        dialogBuilder.setPositiveButton("Try Again", null);
        dialogBuilder.show();
    }

    private void logUserIn(User returnedUser) {
        us.storeUserData(returnedUser);
        us.setUserLoggedIn(true);

        startActivity(new Intent(this, MainActivity.class));


    }
    @Override
    public void onBackPressed() {
            final Context context = this;
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("Are you sure want to quit?");


            alertDialogBuilder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    intent.addCategory(Intent.CATEGORY_HOME);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finishAffinity();
                }
            });


        alertDialogBuilder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    Intent intent = new Intent(context, Login.class);
                    startActivity(intent);
                }
            });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }


}




