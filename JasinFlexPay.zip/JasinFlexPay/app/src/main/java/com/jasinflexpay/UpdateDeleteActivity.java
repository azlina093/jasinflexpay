package com.jasinflexpay;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class UpdateDeleteActivity extends AppCompatActivity {

    JSONParser jParser = new JSONParser();
   // String url_update_mhs= "http://jasinflexpay.netii.net/crud_vehicle/update_vehicle.php";
    String url_delete_mhs= "http://jasinflexpay.netii.net/crud_vehicle/delete_vehicle.php";

    public static final String TAG_SUCCESS = "success";
    public static final String TAG_VEH_NUM = "veh_num";
   // public static final String TAG_MANUFACTURER = "manufacturer";
   // public static final String TAG_MODEL = "model";

    EditText EditTxtman, EditTxtmodel;
    TextView TxtViewveh_num;
    Button  DeleteBtn;
    String  veh_numStr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updatedelete);

        EditTxtman = (EditText) findViewById(R.id.etman);
        EditTxtmodel = (EditText) findViewById(R.id.etmodel);
        TxtViewveh_num = (TextView) findViewById(R.id.veh_num);

       // UpdateBtn = (Button) findViewById(R.id.buttonUpdate);
        DeleteBtn = (Button) findViewById(R.id.buttonDelete);

        Bundle b = getIntent().getExtras();
        String isi_veh_num = b.getString("veh_num");
        String isi_manufacturer= b.getString("manufacturer");
        String isi_model= b.getString("model");

        EditTxtman.setText(isi_manufacturer);
        EditTxtmodel.setText(isi_model);
        TxtViewveh_num.setText(isi_veh_num);

   /*     UpdateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                veh_numStr = TxtViewveh_num.getText().toString();
                manufacturerStr = EditTxtman.getText().toString();
                modelStr = EditTxtmodel.getText().toString();
                new UpdateMhsTask().execute();
            }
        });*/

        DeleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                veh_numStr = TxtViewveh_num.getText().toString();
                new DeleteMhsTask().execute();
            }
        });

    }

    /*class UpdateMhsTask extends AsyncTask<String, Void, String>
    {
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(UpdateDeleteActivity.this);
            pDialog.setMessage("Processing..");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        @Override
        protected String doInBackground(String... sText) {

            List<NameValuePair> parameter = new ArrayList<NameValuePair>();
            parameter.add(new BasicNameValuePair(TAG_VEH_NUM, veh_numStr));
            parameter.add(new BasicNameValuePair(TAG_MANUFACTURER, manufacturerStr));
            parameter.add(new BasicNameValuePair(TAG_MODEL, modelStr));

            try {
                JSONObject json = jParser.makeHttpRequest(url_update_mhs,"POST", parameter);

                int success = json.getInt(TAG_SUCCESS);
                if (success == 1) {

                    return "OK";
                }
                else {

                    return "FAIL";

                }

            } catch (Exception e) {
                e.printStackTrace();
                return "Exception Caught";
            }

        }

        @Override
        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            pDialog.dismiss();

            if(result.equalsIgnoreCase("Exception Caught"))
            {

                Toast.makeText(UpdateDeleteActivity.this, "Unable to connect to server,please check your internet connection!", Toast.LENGTH_LONG).show();
            }

            if(result.equalsIgnoreCase("FAIL"))
            {
                Toast.makeText(UpdateDeleteActivity.this, "Fail.. Try Again", Toast.LENGTH_LONG).show();
            }

            else {
                Toast.makeText(UpdateDeleteActivity.this, "Successfully Update!", Toast.LENGTH_LONG).show();
                Intent i = null;
                i = new Intent(UpdateDeleteActivity.this, Edit_Vehicle.class);
                startActivity(i);
            }

        }
    }*/


    class DeleteMhsTask extends AsyncTask<String, Void, String>
    {
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(UpdateDeleteActivity.this);
            pDialog.setMessage("Processing..");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        @Override
        protected String doInBackground(String... sText) {

            List<NameValuePair> parameter = new ArrayList<NameValuePair>();
            parameter.add(new BasicNameValuePair(TAG_VEH_NUM, veh_numStr));

            try {
                JSONObject json = jParser.makeHttpRequest(url_delete_mhs,"POST", parameter);

                int success = json.getInt(TAG_SUCCESS);
                if (success == 1) {

                    return "OK";
                }
                else {

                    return "FAIL";

                }

            } catch (Exception e) {
                e.printStackTrace();
                return "Exception Caught";
            }

        }

        @Override
        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            pDialog.dismiss();

            if(result.equalsIgnoreCase("Exception Caught"))
            {

                Toast.makeText(UpdateDeleteActivity.this, "Unable to connect to server,please check your internet connection!", Toast.LENGTH_LONG).show();
            }

            if(result.equalsIgnoreCase("FAIL"))
            {
                Toast.makeText(UpdateDeleteActivity.this, "Fail.. Try Again", Toast.LENGTH_LONG).show();
            }

            else {
                Intent i = null;
                i = new Intent(UpdateDeleteActivity.this, Edit_Vehicle.class);
                startActivity(i);
            }

        }
    }

}
