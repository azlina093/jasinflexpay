package com.jasinflexpay;


interface GetUserCallback {

    public abstract void done (User returnUser);

}
