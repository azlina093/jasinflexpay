package com.jasinflexpay;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity implements View.OnClickListener {

    Button btSubmit,btReset;
    EditText etName,etIc,etNum,etPin,etPin2;
    String name,ic,phone_num;
    int pin,pin2,points;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        etName = (EditText) findViewById(R.id.etName);
        etIc = (EditText) findViewById(R.id.etIc);
        etNum = (EditText) findViewById(R.id.etNum);
        etPin = (EditText) findViewById(R.id.etPin);
        etPin2 = (EditText) findViewById(R.id.etPin2);
        btSubmit = (Button) findViewById(R.id.btSubmit);
        btReset = (Button) findViewById(R.id.btReset);

        btSubmit.setOnClickListener(this);
        btReset.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btSubmit:

               name = etName.getText().toString();
               ic = etIc.getText().toString();
               phone_num = etNum.getText().toString();



                if (etPin.getText().toString().matches("")) {
                    etPin.equals("0");
                }
                if (etPin2.getText().toString().matches("")) {
                    etPin2.equals("0");
                }

                //
                //if ("".equals(etPin) )
                //{   etPin.setError( "PIN is required!" );}
               //pin2 = Integer.parseInt(etPin2.getText().toString());
               // if ("".equals(etPin2) )
               // {   etPin.setError( "Please Re-Type PIN!" );}

                if(etPin.getText().length() == 0 ){
                    etPin.setError( "PIN is required!" );}
                else
                {pin = Integer.parseInt(etPin.getText().toString());}

                if(etPin2.getText().length() == 0 ){
                    etPin2.setError( "Re-type PIN is required!" );}
                else
                {pin2 = Integer.parseInt(etPin2.getText().toString());}


                    if (etName.getText().toString().length() == 0)
                        etName.setError("Name is required!");

                    if (etIc.getText().toString().length() == 0)
                        etIc.setError("Identification Number is required!");

                    if (etIc.getText().toString().length() < 12)
                        etIc.setError("Identification Number must be 12 long!");

                    if (etNum.getText().toString().length() == 0)
                        etNum.setError("Phone Number is required!");

                    if (etNum.getText().toString().length() < 10)
                        etNum.setError("Please enter valid Phone Number!");



                    if (etPin2.getText().length() < 5)
                        etPin2.setError("PIN must be 5 long!");


                    if (etPin.getText().length() < 5)
                        etPin.setError("PIN must be 5 long!");

                if ((etName.getText().length() > 0)&& (etIc.getText().length() > 0)&& (etNum.getText().length() > 0)&& (etPin.getText().length() > 0)&& (etPin2.getText().length() > 0)) {

                                    checkPIN(pin, pin2);}
                    else{
                    Toast.makeText(getApplicationContext(), "Please Fill up the form",
                            Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.btReset:

                Intent loginIntent = new Intent(this, Registration.class);
                startActivity(loginIntent);

        }
    }

    public boolean checkPIN(int etpin,int etpin2) {
        boolean pstatus = false;
        if ((etpin2 != 0) && (etpin != 0)) {

                if (etpin == etpin2) {
                    pstatus = true;

                    if ((etName.getText().length() > 0)&& (etIc.getText().length() > 0)&& (etNum.getText().length() > 0)) {
                        final Context context = this;
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                        alertDialogBuilder.setMessage("Are you sure want to submit?");


                        alertDialogBuilder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                User user = new User(name, ic, phone_num, pin, pin2, points);
                                registerUser(user);
                            }
                        });


                        alertDialogBuilder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                Intent intent = new Intent(context, Registration.class);
                                startActivity(intent);
                            }
                        });

                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();

                    }
                }else
            Toast.makeText(getApplicationContext(), "PINs do not match",
                    Toast.LENGTH_LONG).show();
        }
        return pstatus;
    }

    @Override
    public void onBackPressed() {}



   private void registerUser(User user) {
       ServerRequest serverRequest = new ServerRequest(this);
       serverRequest.storeUserDataInBackground(user, new GetUserCallback() {
           @Override
          public void done(User returnedUser) {
               Intent loginIntent = new Intent(Registration.this, Login.class);
               startActivity(loginIntent);
           }
       });
   }


}