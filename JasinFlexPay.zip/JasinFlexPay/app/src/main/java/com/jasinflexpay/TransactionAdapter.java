package com.jasinflexpay;


import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class TransactionAdapter extends BaseAdapter {

        private Activity activity;
        //private ArrayList<HashMap<String, String>> data;
        private ArrayList<Transaction> data_mhs = new ArrayList<Transaction>();

        private static LayoutInflater inflater = null;

        public TransactionAdapter(Activity a, ArrayList<Transaction> d) {
            activity = a;
            data_mhs = d;
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

    public TransactionAdapter(Confirmation confirmation) {

    }

    public int getCount() {
            return data_mhs.size();
        }

        public Object getItem(int position) {
            return data_mhs.get(position);
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            View vi = convertView;
            if (convertView == null)
                vi = inflater.inflate(R.layout.list_item_trans, null);
            TextView transId= (TextView) vi.findViewById(R.id.transId_trans);
            TextView points = (TextView) vi.findViewById(R.id.points_trans);
            TextView veh_num = (TextView) vi.findViewById(R.id.veh_num_trans);
            TextView tarikh = (TextView) vi.findViewById(R.id.tarikh_trans);
            TextView timecheckin = (TextView) vi.findViewById(R.id.timecheckin_trans);
            TextView hours = (TextView) vi.findViewById(R.id.hours_trans);
            TextView cost = (TextView) vi.findViewById(R.id.cost_trans);
            TextView OIC = (TextView) vi.findViewById(R.id.OIC_trans);
            TextView timecheckout = (TextView) vi.findViewById(R.id.timecheckout_trans);
            TextView OffID = (TextView) vi.findViewById(R.id.OffID_trans);


            Transaction daftar_mhs = data_mhs.get(position);

            transId.setText(daftar_mhs.getTransId()+"");
            points.setText(daftar_mhs.getPoints()+"");
            veh_num.setText(daftar_mhs.getVeh_num());
            tarikh.setText(daftar_mhs.getTarikh());
            timecheckin.setText(daftar_mhs.getTimecheckin());
            hours.setText(daftar_mhs.getHours()+"");
            cost.setText(daftar_mhs.getCost()+"");
            OIC.setText(daftar_mhs.getOIC()+"");
            timecheckout.setText(daftar_mhs.getTimecheckout());
            OffID.setText(daftar_mhs.getOffID()+"");


            return vi;
        }


}

