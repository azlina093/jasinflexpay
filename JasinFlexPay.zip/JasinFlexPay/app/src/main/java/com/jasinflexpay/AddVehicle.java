package com.jasinflexpay;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
public class AddVehicle extends AppCompatActivity {

    JSONParser jsonParser = new JSONParser();
    String url_create_mhs= "http://jasinflexpay.netii.net/crud_vehicle/create_vehicle.php";

    UserStore us;
    public static final String TAG_SUCCESS = "success";
    public static final String TAG_VEH_NUM = "veh_num";
    public static final String TAG_MANUFACTURER = "manufacturer";
    public static final String TAG_MODEL = "model";
    public static final String TAG_PHONE_NUM = "phone_num";


    EditText EditTxtnama, EditTxtnim, EditTxtVN, EditTxtPH;
    Button addBtn;
    String manufacturerStr, modelStr, VNStr, phone_num;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicle);
        addBtn = (Button) findViewById(R.id.buttonAdd);
        EditTxtPH = (EditText) findViewById(R.id.etphone);
        EditTxtVN = (EditText) findViewById(R.id.etvn);
        EditTxtnama = (EditText) findViewById(R.id.etman);
        EditTxtnim = (EditText) findViewById(R.id.etmodel);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VNStr = EditTxtVN.getText().toString();
                manufacturerStr = EditTxtnama.getText().toString();
                modelStr = EditTxtnim.getText().toString();
                phone_num = EditTxtPH.getText().toString();
                new CreateMhsTask().execute();
            }
        });

        us = new UserStore(this);

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (authenticate()== true) {
            displayUserDetails();
        }
    }
    private boolean authenticate(){
        if (us.getLoggedInUser() == null) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            return false;
        }
        return true;
    }

    private void displayUserDetails() {
        User user = us.getLoggedInUser();
        EditTxtPH.setText(user.phone_num);

    }

    class CreateMhsTask extends AsyncTask<String, String, String> {
        ProgressDialog dialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(AddVehicle.this);
            dialog.setMessage("Add Vehicle...");
            dialog.setIndeterminate(false);
            dialog.setCancelable(false);
            dialog.show();
        }

        protected String doInBackground(String... args) {

            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();

            User user = us.getLoggedInUser();
            params.add(new BasicNameValuePair(TAG_PHONE_NUM, user.phone_num));
            params.add(new BasicNameValuePair(TAG_VEH_NUM, VNStr));
            params.add(new BasicNameValuePair(TAG_MANUFACTURER, manufacturerStr));
            params.add(new BasicNameValuePair(TAG_MODEL, modelStr));


            // getting JSON Object
            // Note that create Post url accepts POST method
            JSONObject json = jsonParser.makeHttpRequest(url_create_mhs, "POST", params);

            // check for success tag
            try {
                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {
                    // closing this screen
                    finish();
                } else {
                    return "Database Failed";
                }
            } catch (JSONException e) {
                e.printStackTrace();
                return "Connection Failed_or_exception";
            }

            return "success";

        }


        protected void onPostExecute(String result) {

            super.onPostExecute(result);
            if (result.equalsIgnoreCase("failed")){
                dialog.dismiss();
                Toast.makeText(AddVehicle.this, "Connection Failed!", Toast.LENGTH_SHORT).show();
            }
            else if (result.equalsIgnoreCase("failed")){
                dialog.dismiss();
                Toast.makeText(AddVehicle.this, "Connection Failed!", Toast.LENGTH_SHORT).show();

            }
            else if (result.equalsIgnoreCase("success")){
                dialog.dismiss();
                Intent i = null;
                i = new Intent(AddVehicle.this, Edit_Vehicle.class);
                startActivity(i);
            }
        }
    }
 }
