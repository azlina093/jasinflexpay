package com.jasinflexpay;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

public class TimeChanged extends BroadcastReceiver{
    public TimeChanged() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
       Calendar c = Calendar.getInstance();

    }
}

