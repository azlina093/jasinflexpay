package com.jasinflexpay;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class History extends AppCompatActivity {


    ListView list;
    int points;
    String veh_num;


    JSONParser jParser = new JSONParser();
    ArrayList<Transaction> daftar_mhs = new ArrayList<Transaction>();
    JSONArray daftarMhs = null;
    String url_read_mhs = "http://jasinflexpay.netii.net/crud_transaction/read_trans.php?phone_num=";
    UserStore us;


    public static final String TAG_SUCCESS = "success";
    public static final String TAG_TRANSACTION= "transaction";
    public static final String TAG_TRANSID = "transId";
    public static final String TAG_POINTS = "points";
    public static final String TAG_VEH_NUM = "veh_num";
    public static final String TAG_TARIKH = "tarikh";
    public static final String TAG_TIMECHECKIN = "timecheckin";
    public static final String TAG_HOURS = "hours";
    public static final String TAG_COST = "cost";
    public static final String TAG_OIC = "OIC";
    public static final String TAG_TIMECHECKOUT = "timecheckout";
    public static final String TAG_OFFID ="OffID";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        us = new UserStore(this);

        list = (ListView) findViewById(R.id.listview_trans);

        ReadMhsTask m = (ReadMhsTask) new ReadMhsTask().execute();

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int urutan, long id) {


                TextView ti = (TextView) findViewById(R.id.transId_trans);
                TextView po = (TextView) findViewById(R.id.points_trans);
                TextView ho = (TextView) findViewById(R.id.hours_trans);
                TextView co = (TextView) findViewById(R.id.cost_trans);
                TextView oi = (TextView) findViewById(R.id.OIC_trans);
                TextView of = (TextView) findViewById(R.id.OffID_trans);



                int transId = Integer.parseInt(ti.getText().toString());
                int points = Integer.parseInt(po.getText().toString());
                String veh_num = ((TextView) view.findViewById(R.id.veh_num_trans)).getText().toString();
                String tarikh = ((TextView) view.findViewById(R.id.tarikh_trans)).getText().toString();
                String timecheckin = ((TextView) view.findViewById(R.id.timecheckin_trans)).getText().toString();
                int hours = Integer.parseInt(ho.getText().toString());
                int cost = Integer.parseInt(co.getText().toString());
                int OIC = Integer.parseInt(oi.getText().toString());
                String timecheckout = ((TextView) view.findViewById(R.id.timecheckout_trans)).getText().toString();
                int OffID = Integer.parseInt(of.getText().toString());

                Intent i = null;
                i = new Intent(History.this, DeleteTrans.class);
                Bundle b = new Bundle();
                b.putString("transId", String.valueOf(transId));
                b.putString("points", String.valueOf(points));
                b.putString("veh_num", veh_num);
                b.putString("tarikh", tarikh);
                b.putString("timecheckin", timecheckin);
                //b.putString("hours", String.valueOf(hours));
                //b.putString("cost", String.valueOf(cost));
                //b.putString("OIC", String.valueOf(OIC));
                b.putString("timecheckout", timecheckout);
                //b.putString("OffID", String.valueOf(OffID));

                i.putExtras(b);
                startActivity(i);



            }
        });

    }








    class ReadMhsTask extends AsyncTask<String, Void, String> {
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(History.this);
            pDialog.setMessage("Processing..");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        @Override
        protected String doInBackground(String... sText) {
            String returnResult = getTransList();
            return returnResult;

        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pDialog.dismiss();
            if (result.equalsIgnoreCase("Exception Caught")) {
                Toast.makeText(History.this, "Unable to connect to server,please check your internet connection!", Toast.LENGTH_LONG).show();
            }

            if (result.equalsIgnoreCase("no results")) {
                Toast.makeText(History.this, "Data empty", Toast.LENGTH_LONG).show();
            } else {
                list.setAdapter(new TransactionAdapter(History.this,daftar_mhs));
            }
        }


        public String getTransList() {
            Transaction tempMhs = new Transaction();
            List<NameValuePair> parameter = new ArrayList<NameValuePair>();
            try {
                User user = us.getLoggedInUser();
                JSONObject json = jParser.makeHttpRequest(url_read_mhs+user.phone_num,"POST", parameter);

                int success = json.getInt(TAG_SUCCESS);
                if (success == 1) {
                    daftarMhs = json.getJSONArray(TAG_TRANSACTION);
                    for (int i = 0; i < daftarMhs.length(); i++) {
                        JSONObject c = daftarMhs.getJSONObject(i);
                        tempMhs = new Transaction();
                        tempMhs.setTransId(Integer.parseInt(c.getString(TAG_TRANSID)));
                        tempMhs.setPoints(c.getInt(String.valueOf(TAG_POINTS)));
                        tempMhs.setVeh_num(c.getString(TAG_VEH_NUM));
                        tempMhs.setTarikh(c.getString(TAG_TARIKH));
                        tempMhs.setTimecheckin(c.getString(TAG_TIMECHECKIN));
                        tempMhs.setHours(c.getInt(String.valueOf(TAG_HOURS)));
                        tempMhs.setCost(c.getInt(String.valueOf(TAG_COST)));
                        tempMhs.setOIC(c.getInt(String.valueOf(TAG_OIC)));
                        tempMhs.setTimecheckout(c.getString(TAG_TIMECHECKOUT));
                        tempMhs.setOffID(c.getInt(String.valueOf(TAG_OFFID)));


                        daftar_mhs.add(tempMhs);
                    }
                    return "OK";
                } else {

                    return "no results";
                }

            } catch (Exception e) {
                e.printStackTrace();
                return "Exception Caught";
            }
        }

    }

    @Override
    public void onBackPressed() {}



}