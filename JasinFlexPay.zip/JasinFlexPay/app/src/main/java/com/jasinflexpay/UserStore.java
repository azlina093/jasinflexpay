package com.jasinflexpay;

import android.content.Context;
import android.content.SharedPreferences;

public class UserStore {
    public static final String SP_NAME = "userDetails";


    SharedPreferences userDatabase;
    SharedPreferences.Editor spEditor;
    Context context;

    public UserStore(Context context) {

        this.context=context;
        userDatabase = context.getSharedPreferences(SP_NAME,0);
        spEditor = userDatabase.edit();
    }

    public void storeUserData(User user){
        spEditor = userDatabase.edit();
        spEditor.putString("name", user.name);
        spEditor.putString("ic", user.ic);
        spEditor.putString("phone_num", user.phone_num);
        spEditor.putInt("pin", user.pin);
        spEditor.putInt("pin2", user.pin2);
        spEditor.putInt("points", user.points);
        spEditor.commit();

    }

    public User getLoggedInUser(){

        if (userDatabase.getBoolean("loggedIn", false) == false) {
            return null;
        }
        String name = userDatabase.getString("name", "");
        String ic = userDatabase.getString("ic","");
        String phone_num = userDatabase.getString("phone_num","");
        int pin = userDatabase.getInt("pin", -1);
        int pin2 = userDatabase.getInt("pin2",-1);
        int points= userDatabase.getInt("points",-1);

        User user = new User(name,ic,phone_num,pin,pin2,points);
        return user;

    }

    public void setUserLoggedIn(boolean loggedIn){
        SharedPreferences.Editor spEditor =userDatabase.edit();
        spEditor.putBoolean("loggedIn",loggedIn);
        spEditor.commit();
    }



    public void clearUserData(){
        SharedPreferences.Editor spEditor =userDatabase.edit();
        spEditor.clear();
        spEditor.commit();

    }

}
